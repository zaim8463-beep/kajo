package com.hoda.scripts.model;

import org.json.JSONArray;

/** A user-owned shortcut as displayed in the library. */
public class Shortcut {
    public long id;
    public String name;
    public String color;
    public String icon;
    public String folder;
    public boolean favorite;
    public JSONArray actions;
    public long updatedAt;

    public Shortcut(long id, String name, String color, String icon, JSONArray actions, long updatedAt) {
        this(id, name, color, icon, "", false, actions, updatedAt);
    }

    public Shortcut(long id, String name, String color, String icon, String folder,
                    boolean favorite, JSONArray actions, long updatedAt) {
        this.id=id;
        this.name=name == null ? "" : name;
        this.color=color == null ? "#EAE5FF" : color;
        this.icon=icon == null ? "⚡" : icon;
        this.folder=folder == null ? "" : folder;
        this.favorite=favorite;
        this.actions=actions == null ? new JSONArray() : actions;
        this.updatedAt=updatedAt;
    }
}
