package com.hoda.scripts.model;

/** Named screen region with independent, real gesture timing settings. */
public class ScreenRegion {
    public long id;
    public String name, color;
    public int x, y, width, height;
    public long tapDurationMs;
    public long tapSpeedMs;
    public long holdDurationMs;
    public long swipeDurationMs;
    public long swipeSpeedPxPerSec;
    public int repetitions;
    public long intervalMs;
    public String actionMode;
    public long iconTapDurationMs;
    public long iconLongPressDurationMs;
    public long iconDoubleTapDurationMs;
    public long updatedAt;

    public ScreenRegion(long id, String name, String color, int x, int y, int width, int height,
                        long tapDurationMs, long tapSpeedMs, long holdDurationMs,
                        long swipeDurationMs, long swipeSpeedPxPerSec, int repetitions, long intervalMs,
                        String actionMode, long iconTapDurationMs, long iconLongPressDurationMs,
                        long iconDoubleTapDurationMs, long updatedAt) {
        this.id=id; this.name=name==null?"":name; this.color=color==null?"#EAE5FF":color;
        this.x=x; this.y=y; this.width=Math.max(1,width); this.height=Math.max(1,height);
        this.tapDurationMs=clamp(tapDurationMs,0,1000);
        this.tapSpeedMs=clamp(tapSpeedMs,0,1000);
        this.holdDurationMs=clamp(holdDurationMs,0,1000);
        this.swipeDurationMs=clamp(swipeDurationMs,0,1000);
        this.swipeSpeedPxPerSec=clamp(swipeSpeedPxPerSec,0,100000);
        this.repetitions=(int)clamp(repetitions,1,100);
        this.intervalMs=clamp(intervalMs,0,1000);
        this.actionMode=(actionMode==null||actionMode.isEmpty())?"tap":actionMode;
        this.iconTapDurationMs=clamp(iconTapDurationMs,0,1000);
        this.iconLongPressDurationMs=clamp(iconLongPressDurationMs,1,1000);
        this.iconDoubleTapDurationMs=clamp(iconDoubleTapDurationMs,1,1000);
        this.updatedAt=updatedAt;
    }
    private static long clamp(long v,long min,long max){return Math.max(min,Math.min(max,v));}
    public int centerX(){return x+width/2;}
    public int centerY(){return y+height/2;}
}
