package com.hoda.scripts.accessibility;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.accessibility.AccessibilityEvent;
import com.hoda.scripts.model.ScreenRegion;

/**
 * User-enabled Accessibility bridge. Gesture durations are passed to Android's
 * GestureDescription directly; the OS may still impose scheduling/hardware limits.
 */
public final class HodaAccessibilityService extends AccessibilityService {
    private static volatile HodaAccessibilityService instance;
    private FrameLayout bubbleRoot;
    private WindowManager bubbleManager;
    private WindowManager.LayoutParams bubbleParams;
    private boolean bubbleLocked;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override protected void onServiceConnected(){super.onServiceConnected();instance=this;}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){removeRegionBubble();if(instance==this)instance=null;super.onDestroy();}
    public static boolean isConnected(){return instance!=null;}

    public static boolean perform(String action){
        HodaAccessibilityService s=instance;if(s==null)return false;int id;
        switch(action){case"back":id=GLOBAL_ACTION_BACK;break;case"home":id=GLOBAL_ACTION_HOME;break;
            case"recents":id=GLOBAL_ACTION_RECENTS;break;case"notifications":id=GLOBAL_ACTION_NOTIFICATIONS;break;
            case"quick_settings":id=GLOBAL_ACTION_QUICK_SETTINGS;break;case"power_dialog":id=GLOBAL_ACTION_POWER_DIALOG;break;
            default:return false;}return s.performGlobalAction(id);
    }

    public static boolean hold(float x,float y,long durationMs){
        HodaAccessibilityService s=instance;if(s==null||Build.VERSION.SDK_INT<24||x<0||y<0)return false;
        long d=executionDuration(durationMs);Path p=new Path();p.moveTo(x,y);
        GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,d)).build();
        return s.dispatchGesture(g,null,null);
    }
    public static boolean tap(float x,float y){return hold(x,y,80);}

    private static long executionDuration(long ms){return Math.max(1,Math.min(1000,ms));}

    public static void runHoldSequence(float x,float y,long durationMs,int repetitions,long intervalMs,Runnable done){
        HodaAccessibilityService s=instance;if(s==null||Build.VERSION.SDK_INT<24){if(done!=null)done.run();return;}
        int reps=Math.max(1,Math.min(100,repetitions));long d=executionDuration(durationMs);long gap=Math.max(0,Math.min(1000,intervalMs));
        s.runHoldStep(x,y,d,reps,gap,0,done);
    }
    private void runHoldStep(float x,float y,long d,int reps,long gap,int index,Runnable done){
        if(index>=reps){if(done!=null)done.run();return;}
        Path p=new Path();p.moveTo(x,y);
        GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,d)).build();
        boolean accepted=dispatchGesture(g,new GestureResultCallback(){
            @Override public void onCompleted(GestureDescription g){if(gap>0)mainHandler.postDelayed(()->runHoldStep(x,y,d,reps,gap,index+1,done),gap);else runHoldStep(x,y,d,reps,gap,index+1,done);}
            @Override public void onCancelled(GestureDescription g){if(done!=null)done.run();}
        },null);
        if(!accepted&&done!=null)done.run();
    }

    public static void runRegion(ScreenRegion r,float centerX,float centerY,Runnable done){
        HodaAccessibilityService s=instance;if(s==null||r==null){if(done!=null)done.run();return;}
        if("hold".equals(r.actionMode)){
            runHoldSequence(centerX,centerY,r.holdDurationMs,1,0,done);
        }else if("swipe".equals(r.actionMode)){
            float halfW=Math.max(1,r.width/2f);float x1=Math.max(0,centerX-halfW),x2=centerX+halfW;
            float distance=Math.max(1,x2-x1);
            long duration=r.swipeSpeedPxPerSec>0 ? Math.round(distance*1000.0/r.swipeSpeedPxPerSec) : r.swipeDurationMs;
            duration=Math.max(1,Math.min(1000,duration));
            s.runSwipeStep(x1,centerY,x2,centerY,duration,r.repetitions,Math.max(0,Math.min(1000,r.intervalMs)),0,done);
        }else{
            long d=executionDuration(r.tapDurationMs);
            long gap=Math.max(0,Math.min(1000,r.intervalMs));
            if(r.tapSpeedMs>0){
                // Touch speed is a rate: N touches/second. Convert it to a start-to-start period.
                long period=Math.max(1,Math.round(1000.0/r.tapSpeedMs));
                gap=Math.max(0,Math.min(1000,period-d));
            }
            runHoldSequence(centerX,centerY,r.tapDurationMs,r.repetitions,gap,done);
        }
    }
    private void runSwipeStep(float x1,float y1,float x2,float y2,long d,int reps,long gap,int index,Runnable done){
        if(index>=reps){if(done!=null)done.run();return;}
        Path p=new Path();p.moveTo(x1,y1);p.lineTo(x2,y2);
        GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,d)).build();
        boolean accepted=dispatchGesture(g,new GestureResultCallback(){
            @Override public void onCompleted(GestureDescription g){if(gap>0)mainHandler.postDelayed(()->runSwipeStep(x1,y1,x2,y2,d,reps,gap,index+1,done),gap);else runSwipeStep(x1,y1,x2,y2,d,reps,gap,index+1,done);}
            @Override public void onCancelled(GestureDescription g){if(done!=null)done.run();}
        },null);
        if(!accepted&&done!=null)done.run();
    }

    public static boolean showRegionBubble(ScreenRegion r){
        HodaAccessibilityService s=instance;if(s==null||r==null)return false;s.removeRegionBubble();s.createRegionBubble(r);return s.bubbleRoot!=null;
    }
    public static void hideRegionBubble(){HodaAccessibilityService s=instance;if(s!=null)s.removeRegionBubble();}

    private void createRegionBubble(final ScreenRegion r){
        final int size=(int)(64*getResources().getDisplayMetrics().density);
        bubbleRoot=new FrameLayout(this);
        TextView bubble=new TextView(this);bubble.setText("●");bubble.setTextSize(30);bubble.setGravity(Gravity.CENTER);bubble.setTextColor(Color.WHITE);
        GradientDrawable gd=new GradientDrawable();gd.setColor(0xEE7357E8);gd.setShape(GradientDrawable.OVAL);bubble.setBackground(gd);bubble.setElevation(12);
        bubbleRoot.addView(bubble,new FrameLayout.LayoutParams(size,size));
        TextView close=new TextView(this);close.setText("×");close.setTextSize(16);close.setGravity(Gravity.CENTER);close.setTextColor(Color.WHITE);close.setBackgroundColor(0xCC333333);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams((int)(24*getResources().getDisplayMetrics().density),(int)(24*getResources().getDisplayMetrics().density),Gravity.TOP|Gravity.END);
        bubbleRoot.addView(close,cp);close.setOnClickListener(v->removeRegionBubble());
        bubbleManager=(WindowManager)getSystemService(WINDOW_SERVICE);
        bubbleParams=new WindowManager.LayoutParams(size,size,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,android.graphics.PixelFormat.TRANSLUCENT);
        bubbleParams.gravity=Gravity.TOP|Gravity.START;
        bubbleParams.x=Math.max(0,r.centerX()-size/2);bubbleParams.y=Math.max(0,r.centerY()-size/2);
        bubbleManager.addView(bubbleRoot,bubbleParams);bubbleLocked=false;

        final float[] down={0,0};final int[] start={0,0};final long[] downTime={0};
        final boolean[] longFired={false};final Runnable[] longRunnable={null};final int[] tapCount={0};final Runnable[] singleRunnable={null};

        bubble.setOnTouchListener((v,e)->{
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    down[0]=e.getRawX();down[1]=e.getRawY();start[0]=bubbleParams.x;start[1]=bubbleParams.y;downTime[0]=System.currentTimeMillis();longFired[0]=false;
                    longRunnable[0]=()->{if(bubbleRoot!=null&&!longFired[0]){longFired[0]=true;bubbleLocked=!bubbleLocked;bubble.setText(bubbleLocked?"✓":"●");Toast.makeText(this,bubbleLocked?"تم تثبيت الكرة":"تم فك تثبيت الكرة",Toast.LENGTH_SHORT).show();}};
                    mainHandler.postDelayed(longRunnable[0],Math.max(1,Math.min(1000,r.iconLongPressDurationMs)));
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if(!bubbleLocked&&!longFired[0]){
                        bubbleParams.x=start[0]+(int)(e.getRawX()-down[0]);bubbleParams.y=start[1]+(int)(e.getRawY()-down[1]);
                        bubbleManager.updateViewLayout(bubbleRoot,bubbleParams);
                    }return true;
                case MotionEvent.ACTION_UP:
                    if(longRunnable[0]!=null)mainHandler.removeCallbacks(longRunnable[0]);
                    float dx=e.getRawX()-down[0],dy=e.getRawY()-down[1];long held=System.currentTimeMillis()-downTime[0];
                    if(Math.hypot(dx,dy)>=14)return true;
                    if(longFired[0])return true;
                    if(held>Math.max(1,r.iconTapDurationMs))return true;
                    if(!bubbleLocked){
                        bubbleLocked=true;bubble.setText("✓");Toast.makeText(this,"تم تثبيت الكرة",Toast.LENGTH_SHORT).show();return true;
                    }
                    tapCount[0]++;
                    if(tapCount[0]==1){
                        singleRunnable[0]=()->{if(tapCount[0]==1){tapCount[0]=0;runRegion(r,bubbleParams.x+size/2f,bubbleParams.y+size/2f,null);}};
                        mainHandler.postDelayed(singleRunnable[0],Math.max(1,Math.min(1000,r.iconDoubleTapDurationMs)));
                    }else{
                        tapCount[0]=0;if(singleRunnable[0]!=null)mainHandler.removeCallbacks(singleRunnable[0]);
                        runRegion(r,bubbleParams.x+size/2f,bubbleParams.y+size/2f,null);
                        runRegion(r,bubbleParams.x+size/2f,bubbleParams.y+size/2f,null);
                    }
                    return true;
            }return true;
        });
    }

    private void removeRegionBubble(){
        if(bubbleRoot!=null&&bubbleManager!=null){try{bubbleManager.removeView(bubbleRoot);}catch(Exception ignored){}}
        bubbleRoot=null;bubbleManager=null;bubbleParams=null;bubbleLocked=false;
    }
}
