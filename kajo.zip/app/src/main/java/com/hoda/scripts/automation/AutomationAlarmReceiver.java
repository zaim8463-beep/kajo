package com.hoda.scripts.automation;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONObject;

public class AutomationAlarmReceiver extends BroadcastReceiver {
    public static final String EXTRA_RULE_ID="rule_id";
    @Override public void onReceive(Context context,Intent intent){
        String id=intent==null?"":intent.getStringExtra(EXTRA_RULE_ID);
        for(JSONObject rule:AutomationRuleStore.all(context))if(id.equals(rule.optString("id"))&&rule.optBoolean("enabled",true)){
            AutomationRunner.run(context,rule.optLong("shortcut_id"));AutomationScheduler.schedule(context,rule);break;
        }
    }
}
