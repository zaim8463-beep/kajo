package com.hoda.scripts.plugins;

import android.content.Context;
import org.json.JSONObject;

/** Contract for trusted in-process action extensions. Plugins receive parsed config and execution context. */
public interface ShortcutActionPlugin {
    String id();
    String title();
    String category();
    void execute(Context context, JSONObject configuration, Callback callback) throws Exception;
    interface Callback { void onComplete(Object result); void onError(String message); }
}
