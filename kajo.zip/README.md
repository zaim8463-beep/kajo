# Hoda Scripts

Hoda Scripts is a native Android automation app being developed as one continuous project. Its product goal is a practical Android counterpart to Apple Shortcuts: a real shortcut library, visual workflow editor, execution engine, automation triggers, app integrations, and an extensible action system. Android-only capabilities and restrictions are handled explicitly rather than pretending iOS-only APIs exist on Android.

## Development order

Work proceeds in the documented product order. The final APK/release archive is produced only after the planned milestones have been implemented and tested. Intermediate milestone archives are for development review and are not final releases.

## Milestone 1 — Home, library, folders, and Gallery

Implemented in this milestone:

- Main Shortcuts library screen with persistent local SQLite storage.
- Search by shortcut name and folder.
- Library filters: all shortcuts, favourites, and unfiled shortcuts.
- Sorting by recent update, name ascending/descending, and action count.
- User-created folders, folder selection, rename, and delete (shortcuts are moved to Unfiled when a folder is deleted).
- Shortcut cards with icon, colour, action count, folder and favourite state.
- Shortcut context menu: edit, run, duplicate, move to folder, favourite/unfavourite, share, and delete with confirmation.
- Shortcut metadata editing: name, icon, colour, favourite and folder.
- Export the whole library as JSON through Android Sharesheet.
- Import a Hoda JSON shortcut or library backup by paste, and receive shared Hoda JSON text from another app.
- Starter Gallery cards that install usable starter shortcuts into the library.
- Arabic/English labels for the library experience.
- SQLite migration from the earlier database schema, preserving existing shortcuts.

The Gallery currently contains a small starter set; it is not yet the full curated Gallery system. Import/export currently uses JSON text through Android sharing and paste; file-picker based backup/restore and a dedicated versioned interchange specification remain later improvements.

## Milestone 2 — Visual shortcut editor and action library

Implemented in the current working tree:

- A dedicated visual workflow editor with shortcut name, icon, colour, favourite and folder controls.
- Action cards showing order, title, category and configured value.
- Tap an action to edit its configured value; delete it from the edit dialog.
- Long-press and drag an action to reorder it, with move-up/move-down options in the action context menu.
- Duplicate, enable/disable and delete actions from the context menu.
- Searchable action library with action descriptions and categories.
- Structured action records now include type, title, category, value, enabled state and schema version.
- Expanded editor catalog covering text/input, clipboard, wait, control-flow placeholders, variables, lists, dictionaries, URL/HTTP, JSON, notifications, device, app, sharing and file actions.

Milestone 2 provides the visual action-list editor and action definitions. Execution support is described separately under Milestone 3. File actions are implemented in Milestone 4 using the Android document picker.


## Milestone 3 — Action execution engine

Implemented in the current working tree:

- A dedicated sequential execution engine with progress reporting, cancellation, completion output, and action-specific errors.
- Runtime variables (`result`, named values, `repeat_index`, `item`, and `http_status`) and `${variable}` / `$variable` text substitution.
- Text output, ask-for-input dialog, clipboard copy/read (subject to Android clipboard privacy rules), wait, URL launch, app launch by Android package name, notifications, vibration, brightness (requires Modify System Settings), and Android Sharesheet.
- List creation from comma/newline-separated values, JSON dictionary creation, and JSON parsing.
- If/Otherwise branching with `equals`, `not_equals`, `contains`, `starts_with`, `ends_with`, `greater_than`, `less_than`, `is_empty`, and `is_not_empty` operators.
- Repeat and Repeat with Each, including `repeat_index` and `item` runtime variables.
- Choose from Menu with nested action branches.
- HTTP GET and POST on a background I/O thread, with response body in `result` and status code in `http_status`.
- Editor hints with sample JSON structures for structured control-flow and HTTP actions.

Structured action configuration is currently entered in the action value field as JSON. Examples:

- If: `{"left":"$result","operator":"equals","right":"yes","then":[{"type":"text","value":"Matched"}],"else":[]}`
- Repeat: `{"count":3,"actions":[{"type":"notification","value":"Loop ${repeat_index}"}]}`
- Repeat with Each: `{"items":["one","two"],"actions":[{"type":"text","value":"${item}"}]}`
- Choose from Menu: `{"title":"Choose","options":[{"title":"One","actions":[]},{"title":"Two","actions":[]}]}`
- HTTP GET: `{"url":"https://httpbin.org/get"}`
- HTTP POST: `{"url":"https://httpbin.org/post","body":"{\"hello\":\"world\"}"}`

Limitations still open: the editor does not yet provide native visual nested-block editing; structured blocks use JSON configuration. File read/write actions use the Android Storage Access Framework as described in Milestone 4. The engine currently runs while the app's Activity is active; reliable background execution and scheduled trigger orchestration are part of the Automation milestone. HTTP requests have timeouts and accept custom headers in JSON configuration; there is not yet a dedicated authentication-profile editor. Root/plugin actions are not implemented by this milestone.

## Milestone 4 — Files, media, data, and web integrations

Implemented in the current working tree:

- Android Storage Access Framework integration using the system document picker; users explicitly choose files and destinations.
- Read selected text files and create/write text files using `ACTION_OPEN_DOCUMENT` and `ACTION_CREATE_DOCUMENT`.
- Image, video, audio, and PDF selection actions return content URIs instead of unsafe filesystem paths.
- File metadata action returns display name, MIME type, and URI for the selected item.
- Open and share selected media/documents with compatible Android apps using content-URI grants and the Android Sharesheet.
- Persist named variables in app-private SharedPreferences; `Get Variable` checks the current run first and then persistent storage.
- Additional data actions: JSON encoding, list count, indexed list lookup, and append-to-list.
- HTTP GET/POST now accept optional custom request headers in the JSON configuration, allowing caller-supplied API tokens and content negotiation.
- File URI, display name, and MIME type are exposed as runtime variables after media selection.

Examples:

- Read text file: add `Get File` (`file_read`), set its MIME value to `text/plain`, then use `$result`.
- Save text: create a `Text` action first, then `Save File` (`file_write`) with MIME `text/plain`; choose the destination in Android's save dialog.
- Select media: use `pick_image`, `pick_video`, `pick_audio`, or `pick_pdf`; the URI is returned in `$result` and `$file_uri`.
- HTTP headers: `{"url":"https://example.com","headers":{"Authorization":"Bearer YOUR_TOKEN","Accept":"application/json"}}`.
- List append: `{"variable":"items","item":"new value"}`; list lookup: `{"variable":"items","index":0}`.

Important boundaries: media selection, opening, and sharing pass content URIs to other Android apps; this milestone does not implement image/video/audio editing, transcoding, OCR, or PDF text extraction. `Get File` reads text content and should not be used on binary media/PDF files. Persisted named variables are app-local and are not synced between devices. File access is limited to items the user selects; no broad storage permission is requested.

The editor still uses JSON for nested If/Repeat/Menu structures. The foreground service shell exists, but the execution engine is still Activity-hosted; moving full shortcut execution into a robust background service remains future work.

## Existing foundation carried forward

- Native Android app shell with Shortcuts, Automation, Gallery, and Settings tabs.
- Arabic/English interface toggle.
- Initial action registry and basic execution for wait, open URL, text/clipboard, toast notification, and brightness (the latter requires the user to grant Modify System Settings).
- Explicitly user-started Android foreground service with an ongoing notification.
- Settings links for battery optimization and app settings.
- GitHub Actions workflow to build a debug APK.

## Not implemented yet

- Advanced drag-and-drop node graph editing; control-flow blocks now have a form-based visual editor with nested action rows.
- Advanced typed data conversion and variable management UI (persistent named variables are implemented, but remain app-local).
- Dedicated authentication profiles, multipart upload, and richer response parsing.
- Rich per-app action discovery and verified app-specific deep-link contracts; current support is app launch by package and generic Android URL intents.
- Complete automation trigger scheduler and reboot recovery. Foreground-service manual shortcut runs are implemented, but not all interactive actions can run in background.
- Widgets, launcher-pinned shortcuts, and share-sheet input handling beyond shared Hoda JSON.
- Full action Gallery, plugin SDK, plugin permissions, and plugin management.
- Cloud sync, advanced run-history analytics/export, automated tests, and PDF text extraction/media editing.

## Build

Open the repository in Android Studio, or push it to GitHub and run the **Android Build** workflow under Actions. The workflow uses JDK 17 and Gradle and uploads `app-debug.apk` as an artifact.

Requirements: JDK 17 and Android SDK platform 35 / build tools supplied by the Android Gradle Plugin.

## Android capability and permission model

The app cannot silently grant itself special permissions, unrestricted battery access, accessibility access, notification access, or root. These must be requested transparently and approved by the user where Android requires it. Root support is optional and must never be assumed. Android/ColorOS can still restrict background execution. No unsafe kernel or input-driver modifications are performed.

## Project status

Current development milestone: **5.1 — Optional Root background exemptions**. This is an intermediate source project, not the final application. It has not been compiled or tested on a device/emulator in this environment. Do not treat it as a tested release.

## Milestone 4.5 — Visual blocks and foreground execution (0.6.0)

- Added a visual editor for `if`, `repeat`, and `repeat_each` blocks: condition operands/operator, loop count or list variable, and editable nested action rows. Nested condition/repeat blocks can also be edited with the visual editor.
- Added a background-run entry point from the shortcut run dialog. It sends the selected shortcut definition to `AutomationService`, which runs the execution engine in a foreground service with an ongoing notification and updates the notification as actions progress.
- Refactored the execution engine to accept an application `Context`, enabling supported non-interactive actions to run without an Activity.
- Interactive actions that need an Activity (Ask for Input, Choose from Menu, and document picker actions) intentionally fail with a clear background limitation rather than attempting unsafe UI launches from a service.
- Background execution remains subject to Android foreground-service policy, user notification permission, battery management, OEM restrictions, and process termination. It is not an unconditional always-on guarantee.
- This milestone has only been source-checked in this environment. Android SDK/Gradle are unavailable, so no APK build, emulator run, or device test is claimed.


## Milestone 5 — Automation triggers and scheduling (0.7.0)

Implemented in the current working tree:

- Persistent local automation rules that reference shortcuts in the user's library.
- Automation screen to create, enable/disable, and delete rules.
- Daily time-based rules using `AlarmManager.setAndAllowWhileIdle`; the app does not require the special exact-alarm permission. Delivery can be delayed by Android Doze and system scheduling policy.
- System event triggers for power connected/disconnected, battery low/okay, Wi-Fi connected/disconnected, and Bluetooth on/off.
- Daily schedules are restored after `BOOT_COMPLETED`.
- Triggered shortcuts are dispatched through the existing foreground execution service, which displays its ongoing notification.
- Rules are stored locally in app-private preferences and survive normal app restarts.

Important limitations:

- Android and device-vendor background-start restrictions can prevent or delay starting a foreground service from a system broadcast. The app reports/handles failure where it can; this is not a guarantee of always-on execution.
- Wi-Fi and Bluetooth broadcasts can vary by Android release and OEM; Wi-Fi network event details may be restricted.
- App-open/close triggers are not implemented. They require additional usage-access permission and have privacy/battery implications; no silent monitoring is performed.
- Location, NFC, headset, screen, and notification triggers are not included in this milestone.
- Daily time triggers are approximate/inexact, not precision alarms.
- Interactive shortcut actions still require an Activity and cannot complete unattended from a broadcast-triggered background run.
- This milestone has only been source-checked in this environment. No Android SDK/Gradle build or device/emulator test is available here.


## Milestone 5.1 — Optional Root / Magisk background exemptions (0.7.1)

- Added an explicit Root section in Settings with separate actions to check SU access, apply supported background exemptions, and revert those changes.
- Applying changes requires an in-app confirmation followed by the Magisk/SU authorization prompt. Denial makes no requested changes.
- Root operations are scoped to the Hoda Scripts package only: `RUN_IN_BACKGROUND`, `RUN_ANY_IN_BACKGROUND`, and the package's Doze whitelist entry.
- Added per-command success/failure reporting and a revert action that resets the two app-ops to `default` and removes the package from the Doze whitelist.
- No global power-management changes, SELinux disabling, security bypasses, Accessibility auto-grants, or kernel/input-driver modifications are performed.
- Root does not guarantee removal of every Android/ColorOS background restriction. Newer Android releases and OEM firmware may ignore, reject, or override some settings; foreground-service rules and interactive UI requirements still apply.
- This is source-level implementation only. Android SDK/Gradle are unavailable in this environment, so no APK build or device test is claimed.

## Milestone 6 — Android integrations and optional Accessibility (0.8.0)

- Added an installed-app browser in Settings. It lists launchable apps using Android's launcher intent query and lets the user copy a package name for the existing Open App action.
- Added an optional `HodaAccessibilityService`, declared with the system `BIND_ACCESSIBILITY_SERVICE` permission. The user must manually enable it from Android Accessibility settings; the app does not and cannot silently grant this access.
- The service does not request window-content retrieval and intentionally does not collect or persist accessibility event contents.
- Added visual-editor actions `accessibility_global` (Back, Home, Recents, Notifications, Quick Settings, Power dialog) and `accessibility_tap` (a user-configured x/y screen tap). They fail clearly when the service is not enabled/connected.
- Existing Open App, URL/deep-link launch, and Android Sharesheet functionality remain available. App availability and behavior depend on each installed app and Android version.
- Accessibility actions are powerful: use only with workflows you understand. Coordinate taps are screen-size/layout dependent and are not a reliable substitute for semantic UI automation. No automatic text entry, password reading, screen scraping, or hidden event collection is implemented.
- The Settings screen provides a direct link to Android Accessibility settings and reports whether Hoda's service is enabled.
- This is a source milestone, not a verified APK. Build and device testing still require Android SDK/Gradle and a real device. OEM restrictions and Android policy may affect behavior.

## Milestone 7 — Home-screen widgets, pinned shortcuts, sharing and integrations (0.9.0)

Implemented in source:
- Android home-screen widget showing up to four most recently updated shortcuts. Tapping a shortcut starts that saved workflow; tapping the widget header opens Hoda Scripts.
- Android 8+ pinned launcher shortcuts from a shortcut's long-press menu. The launcher controls whether the pin request is accepted.
- Incoming `ACTION_SEND` JSON text and JSON file imports, plus a basic `ACTION_SEND_MULTIPLE` receiver that lets the user select a shared file for JSON import. File import is user-confirmed and capped at 2 MiB.
- `plugin_intent` action for supported `http`, `https`, `mailto`, `tel`, and `geo` deep links, or text sharing through the Android Sharesheet. Optional package targeting is supported for VIEW intents.
- In-process `ShortcutActionPlugin` / `ShortcutPluginRegistry` extension contract for future trusted extensions.
- Widget refresh is requested when the shortcut library is rendered.

Limitations:
- The widget is a compact launcher, not an interactive workflow editor. Android launchers control widget sizing and appearance.
- Pinned shortcuts require Android 8+ and launcher support.
- `ACTION_SEND_MULTIPLE` currently offers a selected shared file for JSON import; it does not bulk-import arbitrary photos, documents, or media into a managed library.
- The plugin registry is an in-process developer extension point only. It does not dynamically discover or load arbitrary third-party APK plugins, and no third-party plugin permissions are silently granted.
- External deep links depend on another installed app having a compatible intent filter.
- Source validation is not equivalent to an Android build or device test. No APK build or on-device verification was performed in this environment.

## Milestone 8 — Notification controls and run feedback (0.10.0)

Implemented in source:
- Added a Stop action to the ongoing foreground execution notification. The action sends an explicit service command, cancels the active execution engine, and stops the foreground service.
- The ongoing notification opens Hoda Scripts when tapped and displays the current shortcut name and action progress.
- Added a completion/failure result notification after a background shortcut finishes, including a concise result or failure reason when available.
- Updated the foreground notification channel description and app version to 0.10.0 (versionCode 11).

Limitations:
- Android notification permission and channel settings remain under user/system control; if notifications are disabled, visible controls/results may not appear.
- Stop requests are cooperative: an action already executing in a blocking system/API call may take time to return before cancellation fully takes effect.
- This milestone does not add always-listening voice activation. Voice input requires an explicit user action and a separate speech-recognition UI/permission design.
- Source-level changes only; no APK build, emulator test, or device test is claimed in this environment.


## Milestone 8 continuation — 0.10.1

- Added user-initiated voice shortcut matching through Android's speech-recognition activity. Hoda does not continuously listen; the user taps the voice button and confirms the selected shortcut before it runs.
- Added a local recent execution history (up to 100 entries) for foreground and foreground-service runs, with success/failure metadata and a clear-history control. It intentionally does not store action inputs or runtime variable values.
- Voice recognition depends on a compatible speech recognition app/service being installed and configured on the device.
- Validation is source-level only; this environment does not provide Android SDK/Gradle for an APK build or device test.

## Milestone 9 — Diagnostics and support report (0.11.0)

Implemented in source:
- Added a Diagnostics and Support section in Settings.
- Added a shareable/copyable diagnostic report with app version, Android API/release, device manufacturer/model, battery-optimization exemption status, Accessibility enabled/connected status, notification availability, and speech-recognition handler availability.
- Added aggregate library/automation/run-history counts and recent success/failure totals.
- The diagnostic report deliberately excludes shortcut names, action definitions, runtime variables, input/output values, file paths, and run-history detail text.
- Added Android package-visibility query for the speech-recognition action so availability checks work on modern Android package-visibility rules.
- Updated app version to 0.11.0 (versionCode 13).

Limitations:
- Diagnostic checks are informational. A granted setting does not guarantee that every action or background task will work on every Android/OEM build.
- The report includes device manufacturer and model; review it before sharing if you do not want to disclose device information.
- Source-level validation only. No Android SDK/Gradle build, emulator run, or physical-device test is claimed.


## Milestone 10 — Recovery and resilient execution (0.12.0)

Implemented in the current working tree:

- Added a dedicated full-library backup flow using Android's Storage Access Framework (`ACTION_CREATE_DOCUMENT`). The versioned `hoda-full-backup-v1` JSON contains shortcut definitions, their actions, folder assignments, favourites, and the folder list.
- Added restore through `ACTION_OPEN_DOCUMENT`, with an explicit destructive confirmation before replacing the current shortcut and folder library.
- Restore validates the format, required arrays, item limits, shortcut names, and top-level action records before applying changes. The SQLite replacement is performed inside a transaction, so a database failure rolls back instead of leaving a partially replaced library.
- Refreshes the home-screen widget after a successful restore.
- Added bounded retry support to HTTP GET/POST action JSON: `retryCount` is clamped to 0–3 (default 0) and `retryDelayMs` to 250–5000 ms (default 750 ms). Network exceptions and HTTP 429/5xx responses are retried; other HTTP status responses are returned to the workflow without retry.
- Updated version to 0.12.0 (versionCode 14).

Example HTTP GET configuration with two retries:

```json
{"url":"https://example.com/api","retryCount":2,"retryDelayMs":1000}
```

Backup scope and limitations:

- The full backup covers the shortcut library and folders only. It deliberately excludes runtime variables, execution history, automation trigger rules, root exemptions, Android permissions, Accessibility state, and system settings.
- Restore replaces the current shortcuts and folders; users are prompted to confirm first.
- The restore file is limited to 5 MB, 500 shortcuts, 200 folders, 1,000 top-level actions per shortcut, and 160 characters per shortcut name.
- HTTP retry is opt-in and bounded; it does not retry ordinary 4xx responses other than 429. Repeated POST requests may repeat server-side effects, so users should only enable retries for endpoints where repeating the request is safe.
- Android SDK/Gradle build and on-device tests have not been run in this environment.
